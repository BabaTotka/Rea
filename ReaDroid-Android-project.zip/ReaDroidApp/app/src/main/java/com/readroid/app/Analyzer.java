package com.readroid.app;

import android.util.Xml;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Static analysis. Never installs, runs or alters the analyzed APK. */
public final class Analyzer {
    private Analyzer() {}

    static final int MAX_ENTRY_BYTES = 24 * 1024 * 1024;
    static final long MAX_TOTAL_BYTES = 200L * 1024 * 1024;
    static final int MAX_ITEMS = 3000;

    static final Pattern URL_RE = Pattern.compile("https?://[^\\s\\x00\"'<>]{4,500}", Pattern.CASE_INSENSITIVE);
    static final String TLDS = "com|net|org|io|dev|app|gov|edu|mil|info|biz|name|pro|xyz|top|online|site|club|vip|link|click|"
            + "shop|store|live|icu|buzz|cyou|work|space|tech|cc|ws|pw|su|me|co|ai|br|ru|cn|tk|ml|ga|cf|gq|onion|duckdns|ngrok";
    static final Pattern DOMAIN_RE = Pattern.compile(
            "\\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:" + TLDS + ")\\b", Pattern.CASE_INSENSITIVE);
    static final Pattern IPV4_RE = Pattern.compile("(?<![0-9.])(?:[0-9]{1,3}\\.){3}[0-9]{1,3}(?![0-9.])");
    static final String[] NOT_DOMAIN = {"android.", "androidx.", "java.", "javax.", "kotlin.", "kotlinx.", "dalvik.",
            "com.android.", "com.google.android.", "org.apache.", "org.json.", "org.w3c.", "org.xml.", "sun.", "libcore."};

    /** Permissions that deserve a closer look (shown in red in the UI). */
    static final String[] SENSITIVE = {"CAMERA", "RECORD_AUDIO", "READ_SMS", "SEND_SMS", "RECEIVE_SMS", "READ_CONTACTS",
            "WRITE_CONTACTS", "READ_CALL_LOG", "CALL_PHONE", "READ_PHONE_STATE", "ACCESS_FINE_LOCATION",
            "ACCESS_COARSE_LOCATION", "ACCESS_BACKGROUND_LOCATION", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE",
            "MANAGE_EXTERNAL_STORAGE", "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE",
            "READ_CALENDAR", "BIND_DEVICE_ADMIN", "RECEIVE_BOOT_COMPLETED", "QUERY_ALL_PACKAGES"};

    public static boolean isSensitive(String perm) {
        String s = perm.substring(perm.lastIndexOf('.') + 1);
        for (String p : SENSITIVE) if (p.equals(s)) return true;
        return false;
    }

    public static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte x : md.digest()) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    public static byte[] readEntry(ZipFile z, ZipEntry e, int max) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = z.getInputStream(e)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) {
                int room = max - out.size();
                if (room <= 0) break;
                out.write(buf, 0, Math.min(n, room));
            }
        }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ 1. inspect

    public static JSONObject inspect(File f, String name, String sha) throws Exception {
        try (ZipFile z = new ZipFile(f)) {
            JSONArray dex = new JSONArray(), libs = new JSONArray();
            int count = 0, res = 0, assets = 0;
            ZipEntry manifest = null;
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                count++;
                if (n.matches("classes\\d*\\.dex")) dex.put(n);
                if (n.startsWith("lib/") && n.endsWith(".so")) libs.put(n);
                if (n.startsWith("res/")) res++;
                if (n.startsWith("assets/")) assets++;
                if (n.equals("AndroidManifest.xml")) manifest = e;
            }
            String kind = "missing";
            if (manifest != null) {
                byte[] d = readEntry(z, manifest, 64);
                int i = 0;
                while (i < d.length && Character.isWhitespace(d[i])) i++;
                kind = i < d.length && d[i] == '<' ? "Text XML" : "Android binary XML (AXML)";
            }
            JSONObject o = new JSONObject();
            o.put("tool", "ReaDroid");
            o.put("file_name", name);
            o.put("file_size_bytes", f.length());
            o.put("sha256", sha);
            o.put("zip_entry_count", count);
            o.put("manifest_present", manifest != null);
            o.put("manifest_format", kind);
            o.put("dex_files", dex);
            o.put("native_libraries", libs);
            o.put("resource_file_count", res);
            o.put("asset_file_count", assets);
            o.put("note", "Static inspection; the presence of a file does not prove malicious behavior.");
            return o;
        }
    }

    // ------------------------------------------------------------------ 2. manifest

    /** Decoded manifest text (XML) of an APK, or throws. */
    public static String manifestXml(File f) throws Exception {
        List<Axml.Ev> ev = manifestEvents(f);
        return Axml.toXml(ev);
    }

    static List<Axml.Ev> manifestEvents(File f) throws Exception {
        try (ZipFile z = new ZipFile(f)) {
            ZipEntry e = z.getEntry("AndroidManifest.xml");
            if (e == null) throw new Exception("AndroidManifest.xml was not found inside the APK.");
            byte[] data = readEntry(z, e, MAX_ENTRY_BYTES);
            return eventsFromBytes(data);
        }
    }

    public static List<Axml.Ev> eventsFromBytes(byte[] data) throws Exception {
        int i = 0;
        while (i < data.length && Character.isWhitespace(data[i])) i++;
        if (i < data.length && data[i] == '<') return textXmlEvents(data);
        return Axml.parse(data);
    }

    static List<Axml.Ev> textXmlEvents(byte[] data) throws Exception {
        List<Axml.Ev> out = new ArrayList<>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(new ByteArrayInputStream(data), null);
        int t = p.getEventType();
        while (t != XmlPullParser.END_DOCUMENT) {
            if (t == XmlPullParser.START_TAG) {
                Map<String, String> attrs = new LinkedHashMap<>();
                for (int i = 0; i < p.getAttributeCount(); i++) {
                    String n = p.getAttributeName(i);
                    attrs.put(n.substring(n.indexOf(':') + 1), p.getAttributeValue(i));
                }
                out.add(new Axml.Ev(true, p.getName(), attrs));
            } else if (t == XmlPullParser.END_TAG) {
                out.add(new Axml.Ev(false, p.getName(), null));
            }
            t = p.next();
        }
        return out;
    }

    public static JSONObject manifest(File f, String name, String sha) throws Exception {
        JSONObject r = new JSONObject();
        JSONArray perms = new JSONArray(), comps = new JSONArray();
        JSONObject app = new JSONObject();
        r.put("tool", "ReaDroid");
        r.put("apk", name);
        r.put("sha256", sha);
        try {
            List<Axml.Ev> events = manifestEvents(f);
            List<String> stack = new ArrayList<>();
            TreeSet<String> seen = new TreeSet<>();
            List<JSONObject> permList = new ArrayList<>();
            for (Axml.Ev e : events) {
                if (!e.start) {
                    if (!stack.isEmpty()) stack.remove(stack.size() - 1);
                    continue;
                }
                String parent = stack.isEmpty() ? null : stack.get(stack.size() - 1);
                stack.add(e.tag);
                Map<String, String> a = e.attrs;
                switch (e.tag) {
                    case "manifest":
                        r.put("package", a.get("package"));
                        r.put("version_code", a.get("versionCode"));
                        r.put("version_name", a.get("versionName"));
                        break;
                    case "uses-sdk":
                        r.put("min_sdk", a.get("minSdkVersion"));
                        r.put("target_sdk", a.get("targetSdkVersion"));
                        break;
                    case "uses-permission":
                    case "uses-permission-sdk-23":
                    case "uses-permission-sdk-m": {
                        String n = a.get("name");
                        if (n != null && seen.add(n)) {
                            JSONObject o = new JSONObject();
                            o.put("name", n);
                            o.put("sensitive", isSensitive(n));
                            permList.add(o);
                        }
                        break;
                    }
                    case "application":
                        app.put("label", a.get("label"));
                        app.put("debuggable", a.get("debuggable"));
                        app.put("allow_backup", a.get("allowBackup"));
                        app.put("uses_cleartext_traffic", a.get("usesCleartextTraffic"));
                        break;
                    case "activity": case "activity-alias": case "service": case "receiver": case "provider":
                        if ("application".equals(parent)) {
                            JSONObject o = new JSONObject();
                            o.put("type", e.tag);
                            o.put("name", a.get("name"));
                            o.put("exported", a.get("exported"));
                            o.put("permission", a.get("permission"));
                            comps.put(o);
                        }
                        break;
                    default:
                }
            }
            permList.sort((x, y) -> x.optString("name").compareTo(y.optString("name")));
            for (JSONObject o : permList) perms.put(o);
            r.put("decoded", true);
        } catch (Exception ex) {
            r.put("decoded", false);
            r.put("reason", String.valueOf(ex.getMessage()));
        }
        r.put("application", app);
        r.put("permissions", perms);
        r.put("components", comps);
        r.put("security_note", "Permissions and flags are signals for review; on their own they do not "
                + "classify an app as safe or malicious.");
        return r;
    }

    // ------------------------------------------------------------------ 3. strings

    public interface Progress { void update(String msg); }

    public static JSONObject scanStrings(File f, String name, String sha, Progress prog) throws Exception {
        TreeSet<String> urls = new TreeSet<>(), domains = new TreeSet<>(), ips = new TreeSet<>();
        TreeSet<String> truncated = new TreeSet<>();
        long scanned = 0;
        int skipped = 0;
        try (ZipFile z = new ZipFile(f)) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                if (e.getSize() > MAX_ENTRY_BYTES) { skipped++; continue; }
                String n = e.getName().toLowerCase();
                boolean ok = n.endsWith(".dex") || n.endsWith(".xml") || n.endsWith(".arsc") || n.endsWith(".so")
                        || n.endsWith(".txt") || n.endsWith(".json") || n.endsWith(".js") || n.endsWith(".html")
                        || n.endsWith(".properties") || n.endsWith(".smali") || n.startsWith("assets/");
                if (!ok) continue;
                if (scanned >= MAX_TOTAL_BYTES) break;
                if (prog != null) prog.update(e.getName());
                byte[] data;
                try { data = readEntry(z, e, MAX_ENTRY_BYTES); } catch (Exception ex) { continue; }
                scanned += data.length;
                String text = new String(data, StandardCharsets.ISO_8859_1);
                Matcher m = URL_RE.matcher(text);
                while (m.find()) add(urls, m.group(), "urls", truncated);
                m = DOMAIN_RE.matcher(text);
                while (m.find()) {
                    String d = m.group().toLowerCase();
                    boolean skip = false;
                    for (String pre : NOT_DOMAIN) if (d.startsWith(pre)) { skip = true; break; }
                    if (!skip) add(domains, d, "domains", truncated);
                }
                m = IPV4_RE.matcher(text);
                while (m.find()) {
                    boolean valid = true;
                    for (String part : m.group().split("\\.")) if (Integer.parseInt(part) > 255) valid = false;
                    if (valid) add(ips, m.group(), "ipv4_candidates", truncated);
                }
            }
        }
        JSONObject o = new JSONObject();
        o.put("tool", "ReaDroid");
        o.put("apk", name);
        o.put("sha256", sha);
        o.put("bytes_scanned", scanned);
        o.put("large_entries_skipped", skipped);
        o.put("urls", new JSONArray(urls));
        o.put("domains", new JSONArray(domains));
        o.put("ipv4_candidates", new JSONArray(ips));
        o.put("truncated_categories", new JSONArray(truncated));
        o.put("note", "These are text matches, not confirmation of connections or malicious activity. "
                + "Domains may be library names, documentation or examples.");
        return o;
    }

    private static void add(TreeSet<String> set, String v, String cat, TreeSet<String> truncated) {
        if (set.contains(v)) return;
        if (set.size() >= MAX_ITEMS) { truncated.add(cat); return; }
        set.add(v);
    }
}
