package com.readroid.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class MainActivity extends Activity {
    // White + red theme
    static final int RED = 0xFFD32F2F, DARK_RED = 0xFFB71C1C, WHITE = 0xFFFFFFFF;
    static final int TINT = 0xFFFDECEA, INK = 0xFF212121, GRAY = 0xFF6B6B6B, LINE = 0xFFEAC4C0;

    static final int REQ_PICK = 1, REQ_SAVE_REPORT = 2, REQ_SAVE_ENTRY = 3;
    static final String[] TABS = {"Overview", "Manifest", "Strings", "Files", "About"};
    static final String[] TEXT_EXT = {".xml", ".json", ".txt", ".smali", ".java", ".kt", ".html", ".js", ".css",
            ".properties", ".md", ".yml", ".yaml", ".cfg", ".ini", ".version", ".pro", ".mf", ".sf"};

    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private FrameLayout content;
    private TextView fileLabel, status;
    private final List<TextView> tabViews = new ArrayList<>();
    private final List<View> tabBars = new ArrayList<>();
    private int tab = 0;

    private File apk;
    private String apkName, apkSha;
    private JSONObject inspectJson, manifestJson, scanJson;
    private List<String> entries = new ArrayList<>();
    private String filesFilter = "";
    private boolean busy = false;
    private String pendingEntry;

    // ================================================================== lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(WHITE);
        setContentView(buildRoot());
        showTab(0);
        Intent i = getIntent();
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) loadApk(i.getData());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }

    // ================================================================== UI skeleton

    private View buildRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(WHITE);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(RED);
        header.setPadding(dp(18), dp(14), dp(18), dp(14));
        TextView title = text("ReaDroid", 24, WHITE, true);
        TextView sub = text("APK static analysis · offline · no root", 12, 0xFFFFD6D2, false);
        header.addView(title);
        header.addView(sub);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        // File bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.setBackgroundColor(TINT);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        fileLabel = text("No APK selected", 14, INK, true);
        fileLabel.setSingleLine(true);
        fileLabel.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        status = text("Pick an APK to analyze it", 11, GRAY, false);
        labels.addView(fileLabel);
        labels.addView(status);
        bar.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView pick = button("Select APK", true, v -> pickApk());
        bar.addView(pick, new LinearLayout.LayoutParams(-2, -2));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        // Content
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        // Bottom navigation
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(WHITE);
        View divider = new View(this);
        divider.setBackgroundColor(LINE);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = text(TABS[i], 12, GRAY, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(12), 0, dp(10));
            View ind = new View(this);
            cell.addView(t, new LinearLayout.LayoutParams(-1, -2));
            cell.addView(ind, new LinearLayout.LayoutParams(-1, dp(3)));
            cell.setOnClickListener(v -> showTab(idx));
            tabViews.add(t);
            tabBars.add(ind);
            nav.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        return root;
    }

    private void showTab(int i) {
        tab = i;
        for (int k = 0; k < TABS.length; k++) {
            boolean on = k == i;
            tabViews.get(k).setTextColor(on ? RED : GRAY);
            tabBars.get(k).setBackgroundColor(on ? RED : WHITE);
        }
        content.removeAllViews();
        switch (i) {
            case 0: content.addView(overviewView()); break;
            case 1: content.addView(manifestView()); break;
            case 2: content.addView(stringsView()); break;
            case 3: content.addView(filesView()); break;
            default: content.addView(aboutView());
        }
    }

    private void refresh() { showTab(tab); }

    // ================================================================== helpers

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable box(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView button(String label, boolean filled, View.OnClickListener l) {
        TextView t = text(label, 13, filled ? WHITE : RED, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        t.setBackground(filled ? box(RED, 0, 22) : box(WHITE, RED, 22));
        t.setOnClickListener(l);
        return t;
    }

    private ScrollView scroller(LinearLayout inner) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(inner, new ViewGroup.LayoutParams(-1, -2));
        return sv;
    }

    private LinearLayout page() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(20));
        return l;
    }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(box(WHITE, LINE, 14));
        if (title != null) {
            TextView t = text(title.toUpperCase(), 11, RED, true);
            t.setLetterSpacing(0.08f);
            t.setPadding(0, 0, 0, dp(8));
            c.addView(t);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        parent.addView(c, lp);
        return c;
    }

    private void row(LinearLayout parent, String k, String v) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(4), 0, dp(4));
        TextView a = text(k, 13, GRAY, false);
        TextView b = text(v == null || v.equals("null") ? "-" : v, 13, INK, true);
        b.setGravity(Gravity.END);
        b.setTextIsSelectable(true);
        r.addView(a, new LinearLayout.LayoutParams(0, -2, 0.42f));
        r.addView(b, new LinearLayout.LayoutParams(0, -2, 0.58f));
        parent.addView(r);
    }

    private void line(LinearLayout parent, String s, int color, boolean mono) {
        TextView t = text(s, 12, color, false);
        t.setPadding(0, dp(3), 0, dp(3));
        t.setTextIsSelectable(true);
        if (mono) t.setTypeface(Typeface.MONOSPACE);
        parent.addView(t);
    }

    private void empty(LinearLayout p, String msg) {
        LinearLayout c = card(p, null);
        TextView t = text(msg, 14, GRAY, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(24), 0, dp(16));
        c.addView(t);
        TextView b = button("Select APK", true, v -> pickApk());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = dp(8);
        c.addView(b, lp);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void setStatus(String s) { status.setText(s); }

    private static String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024 * 1024) return String.format("%.1f KB", n / 1024.0);
        return String.format("%.2f MB", n / 1048576.0);
    }

    // ================================================================== loading an APK

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.android.package-archive",
                "application/octet-stream", "application/zip", "*/*"});
        startActivityForResult(i, REQ_PICK);
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) { }
        String p = uri.getLastPathSegment();
        return p == null ? "app.apk" : p.substring(p.lastIndexOf('/') + 1);
    }

    private void loadApk(Uri uri) {
        if (busy) { toast("Please wait, still working…"); return; }
        busy = true;
        setStatus("Reading file…");
        pool.execute(() -> {
            try {
                String name = displayName(uri);
                File dest = new File(getCacheDir(), "current.apk");
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(dest)) {
                    if (in == null) throw new Exception("Cannot open the selected file.");
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                if (dest.length() == 0) throw new Exception("The file is empty.");
                List<String> names = new ArrayList<>();
                try (ZipFile z = new ZipFile(dest)) {
                    Enumeration<? extends ZipEntry> en = z.entries();
                    while (en.hasMoreElements()) names.add(en.nextElement().getName());
                } catch (Exception e) {
                    throw new Exception("That file is not a valid APK/ZIP.");
                }
                String sha = Analyzer.sha256(dest);
                JSONObject ins = Analyzer.inspect(dest, name, sha);
                JSONObject man = Analyzer.manifest(dest, name, sha);
                ui.post(() -> {
                    apk = dest; apkName = name; apkSha = sha;
                    inspectJson = ins; manifestJson = man; scanJson = null;
                    entries = names; filesFilter = "";
                    fileLabel.setText(name);
                    setStatus(human(dest.length()) + " · " + names.size() + " entries");
                    busy = false;
                    refresh();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    busy = false;
                    setStatus(apk == null ? "Pick an APK to analyze it" : human(apk.length()));
                    toast("Failed: " + e.getMessage());
                });
            }
        });
    }

    // ================================================================== tab: Overview

    private View overviewView() {
        LinearLayout p = page();
        if (inspectJson == null) { empty(p, "Select an APK to see its structure, hashes and contents."); return scroller(p); }
        JSONObject o = inspectJson;
        LinearLayout c = card(p, "File");
        row(c, "Name", o.optString("file_name"));
        row(c, "Size", human(o.optLong("file_size_bytes")));
        LinearLayout h = card(p, "SHA-256");
        line(h, o.optString("sha256"), INK, true);
        LinearLayout s = card(p, "Structure");
        row(s, "ZIP entries", String.valueOf(o.optInt("zip_entry_count")));
        row(s, "DEX files", String.valueOf(o.optJSONArray("dex_files").length()));
        row(s, "Native libraries", String.valueOf(o.optJSONArray("native_libraries").length()));
        row(s, "Resource files", String.valueOf(o.optInt("resource_file_count")));
        row(s, "Asset files", String.valueOf(o.optInt("asset_file_count")));
        row(s, "Manifest format", o.optString("manifest_format"));
        JSONArray libs = o.optJSONArray("native_libraries");
        if (libs.length() > 0) {
            LinearLayout l = card(p, "Native libraries");
            for (int i = 0; i < Math.min(libs.length(), 40); i++) line(l, libs.optString(i), INK, true);
            if (libs.length() > 40) line(l, "… +" + (libs.length() - 40) + " more (see report)", GRAY, false);
        }
        LinearLayout n = card(p, null);
        line(n, o.optString("note"), GRAY, false);
        TextView save = button("Save full report (JSON)", true, v -> saveReport());
        p.addView(save, new LinearLayout.LayoutParams(-1, -2));
        return scroller(p);
    }

    // ================================================================== tab: Manifest

    private View manifestView() {
        LinearLayout p = page();
        if (manifestJson == null) { empty(p, "Select an APK to read its manifest and permissions."); return scroller(p); }
        JSONObject m = manifestJson;
        if (!m.optBoolean("decoded")) {
            LinearLayout c = card(p, "Manifest not decoded");
            line(c, m.optString("reason", "Unknown error"), RED, false);
            return scroller(p);
        }
        LinearLayout c = card(p, "App");
        row(c, "Package", m.optString("package"));
        row(c, "Version", m.optString("version_name") + " (" + m.optString("version_code") + ")");
        row(c, "Min / target SDK", m.optString("min_sdk", "-") + " / " + m.optString("target_sdk", "-"));
        JSONObject app = m.optJSONObject("application");
        if (app != null) {
            LinearLayout f = card(p, "Flags");
            flag(f, "debuggable", app.optString("debuggable", ""), "true");
            flag(f, "allowBackup", app.optString("allow_backup", ""), "true");
            flag(f, "usesCleartextTraffic", app.optString("uses_cleartext_traffic", ""), "true");
        }
        JSONArray perms = m.optJSONArray("permissions");
        LinearLayout pc = card(p, "Permissions (" + perms.length() + ")");
        if (perms.length() == 0) line(pc, "None declared.", GRAY, false);
        for (int i = 0; i < perms.length(); i++) {
            JSONObject o = perms.optJSONObject(i);
            boolean s = o.optBoolean("sensitive");
            line(pc, (s ? "● " : "○ ") + o.optString("name"), s ? RED : INK, true);
        }
        if (perms.length() > 0) line(pc, "● red = sensitive, worth reviewing", GRAY, false);
        JSONArray comps = m.optJSONArray("components");
        LinearLayout cc = card(p, "Components (" + comps.length() + ")");
        for (int i = 0; i < comps.length(); i++) {
            JSONObject o = comps.optJSONObject(i);
            boolean exp = "true".equals(o.optString("exported"));
            line(cc, o.optString("type") + (exp ? "  [exported]" : ""), exp ? RED : GRAY, false);
            line(cc, o.optString("name"), INK, true);
        }
        TextView xml = button("View decoded AndroidManifest.xml", false, v -> viewEntry("AndroidManifest.xml"));
        p.addView(xml, new LinearLayout.LayoutParams(-1, -2));
        return scroller(p);
    }

    private void flag(LinearLayout parent, String k, String v, String risky) {
        LinearLayout r = new LinearLayout(this);
        r.setPadding(0, dp(4), 0, dp(4));
        TextView a = text(k, 13, GRAY, false);
        boolean bad = v.equals(risky);
        TextView b = text(v.isEmpty() ? "not set" : v, 13, bad ? RED : INK, true);
        b.setGravity(Gravity.END);
        r.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
        parent.addView(r);
    }

    // ================================================================== tab: Strings

    private View stringsView() {
        LinearLayout p = page();
        if (apk == null) { empty(p, "Select an APK to search for URLs, domains and IPs."); return scroller(p); }
        if (scanJson == null) {
            LinearLayout c = card(p, "Scan");
            line(c, "Searches DEX, XML, assets and native libraries for URLs, domains and IPv4 addresses. "
                    + "This can take a while on large APKs.", GRAY, false);
            TextView go = button("Start scan", true, v -> runScan());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(10);
            c.addView(go, lp);
            return scroller(p);
        }
        JSONObject s = scanJson;
        LinearLayout c = card(p, "Summary");
        row(c, "URLs", String.valueOf(s.optJSONArray("urls").length()));
        row(c, "Domains", String.valueOf(s.optJSONArray("domains").length()));
        row(c, "Candidate IPs", String.valueOf(s.optJSONArray("ipv4_candidates").length()));
        row(c, "Scanned", human(s.optLong("bytes_scanned")));
        if (s.optJSONArray("truncated_categories").length() > 0)
            line(c, "Limit reached for: " + s.optJSONArray("truncated_categories"), RED, false);
        list(p, "URLs", s.optJSONArray("urls"));
        list(p, "Domains", s.optJSONArray("domains"));
        list(p, "IPv4 candidates", s.optJSONArray("ipv4_candidates"));
        LinearLayout n = card(p, null);
        line(n, s.optString("note"), GRAY, false);
        p.addView(button("Save full report (JSON)", true, v -> saveReport()), new LinearLayout.LayoutParams(-1, -2));
        return scroller(p);
    }

    private void list(LinearLayout p, String title, JSONArray a) {
        LinearLayout c = card(p, title + " (" + a.length() + ")");
        if (a.length() == 0) line(c, "None found.", GRAY, false);
        int max = 200;
        for (int i = 0; i < Math.min(a.length(), max); i++) line(c, a.optString(i), INK, true);
        if (a.length() > max) line(c, "… +" + (a.length() - max) + " more in the saved report", GRAY, false);
    }

    private void runScan() {
        if (busy || apk == null) return;
        busy = true;
        setStatus("Scanning…");
        final File f = apk; final String n = apkName, sh = apkSha;
        pool.execute(() -> {
            try {
                JSONObject r = Analyzer.scanStrings(f, n, sh, msg -> ui.post(() -> setStatus("Scanning " + msg)));
                ui.post(() -> {
                    scanJson = r; busy = false;
                    setStatus(human(f.length()) + " · scan finished");
                    refresh();
                });
            } catch (Exception e) {
                ui.post(() -> { busy = false; setStatus("Scan failed"); toast("Scan failed: " + e.getMessage()); });
            }
        });
    }

    // ================================================================== tab: Files

    private View filesView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        if (apk == null) {
            LinearLayout p = page();
            empty(p, "Select an APK to browse and open the files inside it.");
            root.addView(scroller(p), new LinearLayout.LayoutParams(-1, -1));
            return root;
        }
        EditText filter = new EditText(this);
        filter.setHint("Filter files…");
        filter.setSingleLine(true);
        filter.setText(filesFilter);
        filter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        filter.setTextColor(INK);
        filter.setHintTextColor(GRAY);
        filter.setBackground(box(WHITE, RED, 22));
        filter.setPadding(dp(16), dp(10), dp(16), dp(10));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.setMargins(dp(14), dp(12), dp(14), dp(6));
        root.addView(filter, flp);
        TextView count = text("", 11, GRAY, false);
        count.setPadding(dp(18), 0, dp(14), dp(6));
        root.addView(count);

        final List<String> shown = new ArrayList<>();
        final ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shown);
        final Runnable apply = () -> {
            shown.clear();
            String q = filesFilter.toLowerCase();
            for (String e : entries) if (q.isEmpty() || e.toLowerCase().contains(q)) shown.add(e);
            ad.notifyDataSetChanged();
            count.setText(shown.size() + " of " + entries.size() + " files · tap to open");
        };
        apply.run();
        ListView lv = new ListView(this);
        lv.setAdapter(ad);
        lv.setDivider(box(LINE, 0, 0));
        lv.setDividerHeight(dp(1));
        lv.setOnItemClickListener((parent, v, pos, id) -> viewEntry(shown.get(pos)));
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { filesFilter = e.toString(); apply.run(); }
        });
        return root;
    }

    private boolean looksTextual(String name) {
        String n = name.toLowerCase();
        for (String e : TEXT_EXT) if (n.endsWith(e)) return true;
        return false;
    }

    private void viewEntry(String name) {
        if (apk == null) return;
        final File f = apk;
        pool.execute(() -> {
            String body;
            try (ZipFile z = new ZipFile(f)) {
                ZipEntry e = z.getEntry(name);
                if (e == null) throw new Exception("Entry not found");
                byte[] d = Analyzer.readEntry(z, e, 512 * 1024);
                String head = "";
                if (name.toLowerCase().endsWith(".xml") && d.length > 4 && (d[0] & 0xFF) == 0x03 && d[1] == 0x00) {
                    try { body = Axml.toXml(Axml.parse(d)); }
                    catch (Exception ex) { body = "(binary XML could not be decoded: " + ex.getMessage() + ")"; }
                } else if (looksTextual(name)) {
                    body = new String(d, StandardCharsets.UTF_8);
                } else {
                    body = hex(d, 2048) + (e.getSize() > 2048 ? "\n… (" + human(e.getSize()) + " total, first 2 KB shown)" : "");
                }
                if (name.equals("AndroidManifest.xml")) head = "";
                body = head + body;
            } catch (Exception ex) {
                body = "Could not open: " + ex.getMessage();
            }
            final String shown = body;
            ui.post(() -> showViewer(name, shown));
        });
    }

    private String hex(byte[] d, int max) {
        StringBuilder sb = new StringBuilder();
        int n = Math.min(d.length, max);
        for (int i = 0; i < n; i += 16) {
            sb.append(String.format("%06x  ", i));
            StringBuilder asc = new StringBuilder();
            for (int j = 0; j < 16; j++) {
                if (i + j < n) {
                    int v = d[i + j] & 0xFF;
                    sb.append(String.format("%02x ", v));
                    asc.append(v >= 32 && v < 127 ? (char) v : '.');
                } else sb.append("   ");
            }
            sb.append(' ').append(asc).append('\n');
        }
        return sb.toString();
    }

    private void showViewer(String name, String body) {
        ScrollView sv = new ScrollView(this);
        TextView t = text(body, 11, INK, false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(16), dp(8), dp(16), dp(8));
        sv.addView(t);
        new AlertDialog.Builder(this)
                .setTitle(name.substring(name.lastIndexOf('/') + 1))
                .setView(sv)
                .setPositiveButton("Close", null)
                .setNeutralButton("Save file", (d, w) -> saveEntry(name))
                .show();
    }

    // ================================================================== tab: About

    private View aboutView() {
        LinearLayout p = page();
        LinearLayout c = card(p, "ReaDroid for Android");
        line(c, "Version 1.0.0", INK, false);
        line(c, "Static analysis of APK files, fully offline. Files are copied to the app's private cache, "
                + "read-only analysis only, and never uploaded anywhere. The app needs no permissions.", GRAY, false);
        LinearLayout f = card(p, "What it does");
        for (String s : new String[]{"Inspect APK structure, hashes, DEX files and native libraries",
                "Decode the binary AndroidManifest.xml: package, SDK, flags, permissions, exported components",
                "Scan for URLs, domains and IP addresses",
                "Browse every file inside the APK; view text, decoded XML or hex; save files out",
                "Export a complete JSON report",
                "Open .apk files directly from your file manager (Open with → ReaDroid)"})
            line(f, "• " + s, INK, false);
        LinearLayout n = card(p, "Good to know");
        line(n, "Permissions and flags are signals for review. They do not prove an app is safe or malicious.", GRAY, false);
        line(n, "Decompiling to Java (JADX) and rebuilding/signing (Apktool) need desktop-class Java tools and "
                + "remain in the Termux edition of ReaDroid.", GRAY, false);
        line(n, "Use only on APKs you own or are authorized to analyze.", GRAY, false);
        return scroller(p);
    }

    // ================================================================== reports / saving

    private JSONObject fullReport() throws Exception {
        JSONObject r = new JSONObject();
        r.put("tool", "ReaDroid Android");
        r.put("inspection", inspectJson);
        r.put("manifest", manifestJson);
        if (scanJson != null) r.put("strings", scanJson);
        return r;
    }

    private void saveReport() {
        if (inspectJson == null) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        String base = apkName == null ? "app" : apkName.replaceAll("\\.[^.]*$", "");
        i.putExtra(Intent.EXTRA_TITLE, base + "_readroid_report.json");
        startActivityForResult(i, REQ_SAVE_REPORT);
    }

    private void saveEntry(String name) {
        pendingEntry = name;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, name.substring(name.lastIndexOf('/') + 1));
        startActivityForResult(i, REQ_SAVE_ENTRY);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            loadApk(uri);
        } else if (req == REQ_SAVE_REPORT) {
            pool.execute(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(fullReport().toString(2).getBytes(StandardCharsets.UTF_8));
                    ui.post(() -> toast("Report saved"));
                } catch (Exception e) {
                    ui.post(() -> toast("Could not save: " + e.getMessage()));
                }
            });
        } else if (req == REQ_SAVE_ENTRY && apk != null && pendingEntry != null) {
            final File f = apk; final String name = pendingEntry;
            pool.execute(() -> {
                try (ZipFile z = new ZipFile(f);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    ZipEntry e = z.getEntry(name);
                    try (InputStream in = z.getInputStream(e)) {
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    ui.post(() -> toast("File saved"));
                } catch (Exception e) {
                    ui.post(() -> toast("Could not save: " + e.getMessage()));
                }
            });
        }
    }
}
