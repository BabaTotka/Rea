package com.readroid.app;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Reader for Android binary XML (AXML), the format of every real AndroidManifest.xml. No dependencies. */
public final class Axml {
    private Axml() {}

    public static final class Ev {
        public final boolean start;
        public final String tag;
        public final Map<String, String> attrs;
        Ev(boolean start, String tag, Map<String, String> attrs) {
            this.start = start; this.tag = tag; this.attrs = attrs;
        }
    }

    public static final class AxmlException extends Exception {
        public AxmlException(String m) { super(m); }
    }

    private static String resName(int id) {
        switch (id) {
            case 0x01010003: return "name";
            case 0x01010006: return "permission";
            case 0x0101000E: return "enabled";
            case 0x0101000F: return "debuggable";
            case 0x01010010: return "exported";
            case 0x0101020C: return "minSdkVersion";
            case 0x01010270: return "targetSdkVersion";
            case 0x0101026C: return "maxSdkVersion";
            case 0x01010280: return "allowBackup";
            case 0x010104EC: return "usesCleartextTraffic";
            case 0x0101021B: return "versionCode";
            case 0x0101021C: return "versionName";
            case 0x01010001: return "label";
            default: return String.format("res_%08x", id);
        }
    }

    private static int u16(ByteBuffer b, int p) { return b.getShort(p) & 0xFFFF; }

    private static String[] stringPool(byte[] data, ByteBuffer b, int pos) {
        int hsize = u16(b, pos + 2);
        int count = b.getInt(pos + 8);
        int flags = b.getInt(pos + 16);
        int sStart = b.getInt(pos + 20);
        boolean utf8 = (flags & 0x100) != 0;
        int base = pos + sStart;
        String[] out = new String[Math.max(count, 0)];
        for (int i = 0; i < out.length; i++) {
            try {
                int p = base + b.getInt(pos + hsize + 4 * i);
                if (utf8) {
                    int n = data[p++] & 0xFF;
                    if ((n & 0x80) != 0) { n = ((n & 0x7F) << 8) | (data[p++] & 0xFF); }
                    int nb = data[p++] & 0xFF;
                    if ((nb & 0x80) != 0) { nb = ((nb & 0x7F) << 8) | (data[p++] & 0xFF); }
                    out[i] = new String(data, p, nb, StandardCharsets.UTF_8);
                } else {
                    int n = u16(b, p); p += 2;
                    if ((n & 0x8000) != 0) { n = ((n & 0x7FFF) << 16) | u16(b, p); p += 2; }
                    out[i] = new String(data, p, n * 2, StandardCharsets.UTF_16LE);
                }
            } catch (RuntimeException e) {
                out[i] = "";
            }
        }
        return out;
    }

    private static String value(String[] s, int raw, int dtype, int val) {
        if (raw != -1) return raw >= 0 && raw < s.length ? s[raw] : "";
        switch (dtype) {
            case 0x03: return val >= 0 && val < s.length ? s[val] : "";
            case 0x12: return val != 0 ? "true" : "false";
            case 0x10: return Integer.toString(val);
            case 0x11: return "0x" + Integer.toHexString(val);
            case 0x01: return String.format("@0x%08x", val);
            default: return "0x" + Integer.toHexString(val);
        }
    }

    public static List<Ev> parse(byte[] data) throws AxmlException {
        if (data.length < 8) throw new AxmlException("file too small to be an AXML");
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (u16(b, 0) != 0x0003) throw new AxmlException("AXML signature not found (0x0003 expected)");
        int pos = u16(b, 2);
        String[] strings = new String[0];
        int[] resMap = new int[0];
        List<Ev> events = new ArrayList<>();
        try {
            while (pos + 8 <= data.length) {
                int ctype = u16(b, pos), chsize = u16(b, pos + 2), csize = b.getInt(pos + 4);
                if (csize < 8) break;
                if (ctype == 0x0001) {
                    strings = stringPool(data, b, pos);
                } else if (ctype == 0x0180) {
                    int n = (csize - chsize) / 4;
                    resMap = new int[n];
                    for (int i = 0; i < n; i++) resMap[i] = b.getInt(pos + chsize + 4 * i);
                } else if (ctype == 0x0102) {
                    int nameIdx = b.getInt(pos + 20);
                    int attrStart = u16(b, pos + 24), attrSize = u16(b, pos + 26), attrCount = u16(b, pos + 28);
                    String tag = nameIdx >= 0 && nameIdx < strings.length ? strings[nameIdx] : "?";
                    Map<String, String> attrs = new LinkedHashMap<>();
                    for (int i = 0; i < attrCount; i++) {
                        int a = pos + 16 + attrStart + i * attrSize;
                        int nIdx = b.getInt(a + 4), raw = b.getInt(a + 8);
                        int dtype = data[a + 15] & 0xFF, val = b.getInt(a + 16);
                        String name = nIdx >= 0 && nIdx < strings.length ? strings[nIdx] : "";
                        if (name.isEmpty() && nIdx >= 0 && nIdx < resMap.length) name = resName(resMap[nIdx]);
                        attrs.put(name, value(strings, raw, dtype, val));
                    }
                    events.add(new Ev(true, tag, attrs));
                } else if (ctype == 0x0103) {
                    int nameIdx = b.getInt(pos + 20);
                    events.add(new Ev(false, nameIdx >= 0 && nameIdx < strings.length ? strings[nameIdx] : "?", null));
                }
                pos += csize;
            }
        } catch (RuntimeException e) {
            throw new AxmlException("AXML structure truncated or tampered with (" + e.getMessage() + ")");
        }
        if (events.isEmpty()) throw new AxmlException("no XML element found");
        return events;
    }

    /** Rebuild readable XML from the events (the "recovered" manifest). */
    public static String toXml(List<Ev> events) {
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        for (Ev e : events) {
            if (e.start) {
                indent(sb, depth);
                sb.append('<').append(e.tag);
                for (Map.Entry<String, String> a : e.attrs.entrySet()) {
                    String v = a.getValue().replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;");
                    sb.append(' ').append(a.getKey().equals("package") ? "" : "android:").append(a.getKey())
                            .append("=\"").append(v).append('"');
                }
                sb.append(">\n");
                depth++;
            } else {
                depth = Math.max(depth - 1, 0);
                indent(sb, depth);
                sb.append("</").append(e.tag).append(">\n");
            }
        }
        return sb.toString();
    }

    private static void indent(StringBuilder sb, int d) {
        for (int i = 0; i < d; i++) sb.append("  ");
    }
}
