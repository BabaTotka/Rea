# ReaDroid for Android

White-and-red Android app version of ReaDroid: static APK analysis, fully offline, no permissions.

Tabs: **Overview** (hashes, structure) · **Manifest** (package, SDK, flags, permissions, exported components) ·
**Strings** (URLs / domains / IPs) · **Files** (browse, view, save entries) · **About**.
Also exports a full JSON report and appears in "Open with" for `.apk` files.

## Get the APK (no PC needed)
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab → *Build ReaDroid APK* → wait ~3 min.
3. Open the finished run → **Artifacts** → download `ReaDroid-apk` → unzip → install `ReaDroid.apk`.

## Or build in Android Studio
Open this folder, then *Build → Build APK(s)*. (Command line: `gradle assembleRelease` with JDK 17 + Android SDK 34.)
